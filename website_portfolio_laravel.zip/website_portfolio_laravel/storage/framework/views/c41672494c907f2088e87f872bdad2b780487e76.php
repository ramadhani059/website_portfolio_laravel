<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>" />
    <link href="<?php echo e(asset('css/lightbox.min.css')); ?>" rel="stylesheet" />

    <title>My Portfolio | Pratama Ramadhani Wijaya</title>
    <link rel="shortcut icon" href="<?php echo e(asset('Foto/logo-favicon.svg')); ?>" type="image/x-icon" />
  </head>
  <body>
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-danger shadow">
      <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
          <img src="<?php echo e(asset('Foto/logo-itts.svg')); ?>" alt="" width="98.5" height="40" />
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('portfolio')); ?>">Portfolio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('music')); ?>">My Music</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="<?php echo e(route('contact')); ?>">Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Navbar End -->
    <section class="container-fluid py-5" id="portfolio>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="section-title text-center">
              <h2 class="fw-bold text-uppercase text-danger mb-2 py-5">Contact</h2>
            </div>
          </div>
        </div>
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="contact-form text-center">
              <div id="success"></div>
              <form>
                <div class="form-row">
                  <div class="control-group col-sm-6">
                    <input type="text" class="form-control p-4" placeholder="Your Name" />
                    <p class="help-block text-danger"></p>
                  </div>
                  <div class="control-group col-sm-6">
                    <input type="email" class="form-control p-4" placeholder="Your Email" />
                    <p class="help-block text-danger"></p>
                  </div>
                </div>
                <div class="control-group">
                  <input type="text" class="form-control p-4" placeholder="Subject"/>
                  <p class="help-block text-danger"></p>
                </div>
                <div class="control-group">
                  <textarea class="form-control py-3 px-4" rows="5" placeholder="Message"></textarea>
                  <p class="help-block text-danger"></p>
                </div>
                <div>
                  <button class="btn btn-outline-danger" type="submit">Send Message</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Footer Start -->
    <section class="container-fluid bg-danger text-white mt-5 py-1 px-sm-1 px-md-5">
      <div class="container text-center py-5">
        <div class="d-flex justify-content-center mb-4">
          <a class="btn btn-light btn-social px-2 me-3 text-danger" href="https://www.facebook.com/pratama.ramadhani.125?ref=bookmarks&_rdc=1&_rdr"><i class="fab fa-facebook-f"></i></a>
          <a class="btn btn-light btn-social px-2 me-3 text-danger" href="https://twitter.com/callmebujank"><i class="fab fab fa-twitter"></i></a>
          <a class="btn btn-light btn-social px-2 me-3 text-danger" href="https://www.instagram.com/ramadhani059/"><i class="fab fa-instagram"></i></a>
          <a class="btn btn-light btn-social px-2 me-3 text-danger" href="https://github.com/ramadhani059"><i class="fab fa-github"></i></a>
        </div>
        <p class="m-0">Copyright &copy; 2021 Information System. Build by Pratama Ramadhani Wijaya.</p>
      </div>
    </section>
    <!-- Footer End -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\Users\PRATAMARAMADHANIWIJA\Desktop\website_portfolio_laravel\resources\views/contact.blade.php ENDPATH**/ ?>