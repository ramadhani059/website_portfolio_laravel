<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>" />
    <link href="<?php echo e(asset('css/lightbox.min.css')); ?>" rel="stylesheet" />

    <title>My Portfolio | Pratama Ramadhani Wijaya</title>
    <link rel="shortcut icon" href="<?php echo e(asset('Foto/logo-favicon.svg')); ?>" type="image/x-icon" />
  </head>
  <body>
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-danger shadow">
      <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
          <img src="<?php echo e(asset('Foto/logo-itts.svg')); ?>" alt="" width="98.5" height="40" />
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(route('portfolio')); ?>">Portfolio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('music')); ?>">My Music</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Navbar End -->
    <section class="container-fluid py-5" id="portfolio>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="section-title text-center">
              <h2 class="fw-bold text-uppercase text-danger mb-2 py-5">My Portfolio</h2>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-12 text-center mb-2">
              <ul class="list-inline mb-lg-5" id="portfolio-flters">
                  <li class="btn btn-sm btn-outline-danger m-1 active"  data-filter="*">All</li>
                  <li class="btn btn-sm btn-outline-danger m-1 " data-filter=".first">Video</li>
                  <li class="btn btn-sm btn-outline-danger m-1" data-filter=".second">UI/UX Design</li>
                  <li class="btn btn-sm btn-outline-danger m-1" data-filter=".third">Photography</li>
              </ul>
          </div>
      </div>
      <div class="row portfolio-container">
          <div class="col-lg-4 col-md-6 mb-4 portfolio-item third">
            <div class="position-relative overflow-hidden mb-2">
                <img class="img-fluid rounded w-100" src="<?php echo e(asset('Foto/portfolio/photo-3.png')); ?>" alt="">
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mb-4 portfolio-item first">
              <div class="position-relative overflow-hidden mb-2">
                <video controls class="img-fluid rounded w-100" alt=""><source src="<?php echo e(asset('video/video.mp4')); ?>" type="video/mp4"></video>
              </div>
          </div>
          <div class="col-lg-4 col-md-6 mb-4 portfolio-item third">
            <div class="position-relative overflow-hidden mb-2">
                <img class="img-fluid rounded w-100" src="<?php echo e(asset('Foto/portfolio/photo-1.png')); ?>" alt="">
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mb-4 portfolio-item second">
              <div class="position-relative overflow-hidden mb-2">
                  <img class="img-fluid rounded w-100" src="<?php echo e(asset('Foto/portfolio/ui-design-1.png')); ?>" alt="">
              </div>
          </div>
          <div class="col-lg-4 col-md-6 mb-4 portfolio-item third">
              <div class="position-relative overflow-hidden mb-2">
                  <img class="img-fluid rounded w-100" src="<?php echo e(asset('Foto/portfolio/photo-2.png')); ?>" alt="">
              </div>
          </div>
          <div class="col-lg-4 col-md-6 mb-4 portfolio-item second">
              <div class="position-relative overflow-hidden mb-2">
                  <img class="img-fluid rounded w-100" src="<?php echo e(asset('Foto/portfolio/ui-design-2.png')); ?>" alt="">
              </div>
          </div>
          <div class="col-lg-4 col-md-6 mb-4 portfolio-item third">
              <div class="position-relative overflow-hidden mb-2">
                  <img class="img-fluid rounded w-100" src="<?php echo e(asset('Foto/portfolio/photo-4.png')); ?>" alt="">
              </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Footer Start -->
    <section class="container-fluid bg-danger text-white mt-5 py-1 px-sm-1 px-md-5">
      <div class="container text-center py-5">
        <div class="d-flex justify-content-center mb-4">
          <a class="btn btn-light btn-social px-2 me-3 text-danger" href="https://www.facebook.com/pratama.ramadhani.125?ref=bookmarks&_rdc=1&_rdr"><i class="fab fa-facebook-f"></i></a>
          <a class="btn btn-light btn-social px-2 me-3 text-danger" href="https://twitter.com/callmebujank"><i class="fab fab fa-twitter"></i></a>
          <a class="btn btn-light btn-social px-2 me-3 text-danger" href="https://www.instagram.com/ramadhani059/"><i class="fab fa-instagram"></i></a>
          <a class="btn btn-light btn-social px-2 me-3 text-danger" href="https://github.com/ramadhani059"><i class="fab fa-github"></i></a>
        </div>
        <p class="m-0">Copyright &copy; 2021 Information System. Build by Pratama Ramadhani Wijaya.</p>
      </div>
    </section>
    <!-- Footer End -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="<?php echo e(asset('js/jquery-3.4.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\Users\PRATAMARAMADHANIWIJA\Desktop\website_portfolio_laravel\resources\views/portfolio.blade.php ENDPATH**/ ?>