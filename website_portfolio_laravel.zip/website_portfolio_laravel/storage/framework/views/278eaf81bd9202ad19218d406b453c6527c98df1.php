<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>" />
    <link href="<?php echo e(asset('css/lightbox.min.css')); ?>" rel="stylesheet" />

    <title>My Portfolio | Pratama Ramadhani Wijaya</title>
    <link rel="shortcut icon" href="<?php echo e(asset('Foto/logo-favicon.svg')); ?>" type="image/x-icon" />
  </head>
  <body>
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-danger shadow">
      <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
          <img src="<?php echo e(asset('Foto/logo-itts.svg')); ?>" alt="" width="98.5" height="40" />
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="<?php echo e(route('home')); ?>">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('portfolio')); ?>">Portfolio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('music')); ?>">My Music</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Navbar End -->

    <!-- Home Section Start -->
    <section class="home" id="home">
      <div class="container-lg">
        <div class="row min-vh-100 align-items-center align-content-center">
          <div class="col-md-6 mt-5 mt-md-0">
            <div class="home-img text-center">
              <img src="<?php echo e(asset('Foto/profile.png')); ?>" class="rounded-circle mw-100" alt="profile img" />
            </div>
          </div>
          <div class="col-md-6 mt-5 mt-md-0 order-md-first">
            <div class="home-text">
              <p class="text-muted mb-1">Hello I'am</p>
              <h1 class="text-danger text-uppercase fs-1 fw-bold">Pratama Ramadhani</h1>
              <h2 class="fs-4">Mahasiswa Sistem Informasi</h2>
              <p class="mt-4 text-muted" align="justify">
                Hello! I'm Rama, a student from Sidoarjo, Indonesia. I was born in Blitar December 24, 2000. I am a Muslim. I have a hobby of making graphic design. I have a dream to become a programmer.
              </p>
              <a href="#portfolio" class="btn btn-danger pk-3 mt-3">Hire Me</a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Home Section End -->

    <!-- About Section Start -->
    <section class="about" id="about">
      <div class="container-lg py-5">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="section-title text-center">
              <h2 class="fw-bold text-uppercase text-danger mb-5 py-5">About Me</h2>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-5 pb-4 pb-lg-0">
            <img class="img-fluid rounded w-100" src="<?php echo e(asset('Foto/about.jpg')); ?>" alt="" />
          </div>
          <div class="col-lg-7">
            <h2 class="mb-4">Web Developer and UI/UX Designer</h2>
            <p align="justify">Hello! I’m Rama, a UI/UX Designer from Sidoarjo, Indonesia. I enjoy creating functional and minimalist interface for human experience. I have a dream to become a web programmer. <br /></p>
            <div class="row mb-3">
              <div class="col-sm-6 py-2">
                <h6>Name : <span class="text-secondary">Pratama Ramadhani Wijaya</span></h6>
              </div>
              <div class="col-sm-6 py-2">
                <h6>Birthday : <span class="text-secondary">24 December 2000</span></h6>
              </div>
              <div class="col-sm-6 py-2">
                <h6>Major : <span class="text-secondary">S1 Information System</span></h6>
              </div>
              <div class="col-sm-6 py-2">
                <h6>Hobby : <span class="text-secondary">Design Graphic</span></h6>
              </div>
              <div class="col-sm-6 py-2">
                <h6>Phone : <span class="text-secondary">+62 8581 5554 360</span></h6>
              </div>
              <div class="col-sm-6 py-2">
                <h6>Email : <span class="text-secondary">pratamaramadhani059@gmail.com</span></h6>
              </div>
              <div class="col-sm-6 py-2">
                <h6>Address : <span class="text-secondary">Jl. Manyar Tegal 1-A, Surabaya</span></h6>
              </div>
              <div class="col-sm-6 py-2">
                <h6>Freelance : <span class="text-secondary">Available</span></h6>
              </div>
            </div>
            <a href="https://docs.google.com/uc?export=download&id=1i_V0YSuT9IqHl_1bLonCMK4TOwbUyT5z" class="btn blue btn-outline-danger mr-4">Download CV</a>
          </div>
        </div>
      </div>
    </section>
    <!-- About Section End -->

    <!-- Skill Start -->
    <section class="skill" id="skill">
      <div class="container-lg py-5">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="section-title text-center">
              <h2 class="fw-bold text-uppercase text-danger mb-5 py-5">My Skill</h2>
            </div>
          </div>
        </div>
        <div class="row align-items-center">
          <div class="col-md-6">
            <div class="skill mb-4">
              <div class="d-flex justify-content-between">
                <h6 class="font-weight-bold">HTML</h6>
                <h6 class="font-weight-bold">80%</h6>
              </div>
              <div class="progress">
                <div class="progress-bar bg-danger" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
            <div class="skill mb-4">
              <div class="d-flex justify-content-between">
                <h6 class="font-weight-bold">CSS</h6>
                <h6 class="font-weight-bold">70%</h6>
              </div>
              <div class="progress">
                <div class="progress-bar bg-danger" style="width: 70%" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
            <div class="skill mb-4">
              <div class="d-flex justify-content-between">
                <h6 class="font-weight-bold">PHP</h6>
                <h6 class="font-weight-bold">50%</h6>
              </div>
              <div class="progress">
                <div class="progress-bar bg-danger" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="skill mb-4">
              <div class="d-flex justify-content-between">
                <h6 class="font-weight-bold">Javascript</h6>
                <h6 class="font-weight-bold">60%</h6>
              </div>
              <div class="progress">
                <div class="progress-bar bg-danger" style="width: 60%" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
            <div class="skill mb-4">
              <div class="d-flex justify-content-between">
                <h6 class="font-weight-bold">Bootstrap</h6>
                <h6 class="font-weight-bold">75%</h6>
              </div>
              <div class="progress">
                <div class="progress-bar bg-danger" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
            <div class="skill mb-4">
              <div class="d-flex justify-content-between">
                <h6 class="font-weight-bold">Wordpress</h6>
                <h6 class="font-weight-bold">85%</h6>
              </div>
              <div class="progress">
                <div class="progress-bar bg-danger" style="width: 75%" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Skill End -->

    <!-- Qualification Start -->
    <section class="container-fluid py-5" id="qualification">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8">
            <div class="section-title text-center">
              <h2 class="fw-bold text-uppercase text-danger mb-5 py-5">Education & Expericence</h2>
            </div>
          </div>
        </div>
        <div class="row align-items-center">
          <div class="col-lg-6">
            <h3 class="mb-4">My Education</h3>
            <div class="border-left border-danger pt-2 pl-4 ml-2">
              <div class="position-relative ex-me mb-4">
                <i class="far fa-dot-circle text-danger position-absolute" style="top: 2px; left: -35px; font-size: 22px"></i>
                <h5 class="font-weight-bold mb-1">Bachelor's Degree</h5>
                <p class="mb-2"><strong>Institut Teknologi Telkom Surabaya </strong> | <small>2019 - Now</small></p>
              </div>
              <div class="position-relative ex-me mb-4">
                <i class="far fa-dot-circle text-danger position-absolute" style="top: 2px; left: -35px; font-size: 22px"></i>
                <h5 class="font-weight-bold mb-1">Vocational School</h5>
                <p class="mb-2"><strong>SMK Negeri 1 Surabaya </strong> | <small>2016 - 2019</small></p>
              </div>
              <div class="position-relative ex-me mb-4">
                <i class="far fa-dot-circle text-danger position-absolute" style="top: 2px; left: -35px; font-size: 22px"></i>
                <h5 class="font-weight-bold mb-1">Junior High School</h5>
                <p class="mb-2"><strong> SMP Islam Terpadu IBADURRAHMAN Blitar</strong> | <small>2013 - 2016</small></p>
              </div>
              <div class="position-relative ex-me mb-4">
                <i class="far fa-dot-circle text-danger position-absolute" style="top: 2px; left: -35px; font-size: 22px"></i>
                <h5 class="font-weight-bold mb-1">Primary School</h5>
                <p class="mb-2"><strong> SD Islam Terpadu IBADURRAHMAN Blitar</strong> | <small>2013 - 2016</small></p>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <h3 class="mb-4">My Expericence</h3>
            <div class="border-left border-danger pt-2 pl-4 ml-2">
              <div class="position-relative ex-me mb-4">
                <i class="far fa-dot-circle text-danger position-absolute" style="top: 2px; left: -35px; font-size: 22px"></i>
                <h5 class="font-weight-bold mb-1">Head Of KOMINFO Departement</h5>
                <p class="mb-2"><strong>HMSI Institut Teknologi Telkom Surabaya</strong> | <small>2020 - Now</small></p>
              </div>
              <div class="position-relative ex-me mb-4">
                <i class="far fa-dot-circle text-danger position-absolute" style="top: 2px; left: -35px; font-size: 22px"></i>
                <h5 class="font-weight-bold mb-1">Digital Media Team - Designer</h5>
                <p class="mb-2"><strong>BKSS - Institut Teknologi Telkom Surabaya</strong> | <small>2020 - Now</small></p>
              </div>
              <div class="position-relative ex-me mb-4">
                <i class="far fa-dot-circle text-danger position-absolute" style="top: 2px; left: -35px; font-size: 22px"></i>
                <h5 class="font-weight-bold mb-1">Staff Of Web Development Division</h5>
                <p class="mb-2"><strong>CODER - Institut Teknologi Telkom Surabaya</strong> | <small> 2020 - Now</small></p>
              </div>
              <div class="position-relative ex-me mb-4">
                <i class="far fa-dot-circle text-danger position-absolute" style="top: 2px; left: -35px; font-size: 22px"></i>
                <h5 class="font-weight-bold mb-1">Member Of Telkomsel Apprentice Program</h5>
                <p class="mb-2"><strong>LOOP ACADEMY - Telkomsel Sidoarjo</strong> | <small> 2019 - 2020</small></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Qualification End -->

    <!-- Footer Start -->
    <section class="container-fluid bg-danger text-white mt-5 py-1 px-sm-1 px-md-5">
      <div class="container text-center py-5">
        <div class="d-flex justify-content-center mb-4">
          <a class="btn btn-light btn-social px-2 me-3 text-danger" href="https://www.facebook.com/pratama.ramadhani.125?ref=bookmarks&_rdc=1&_rdr"><i class="fab fa-facebook-f"></i></a>
          <a class="btn btn-light btn-social px-2 me-3 text-danger" href="https://twitter.com/callmebujank"><i class="fab fab fa-twitter"></i></a>
          <a class="btn btn-light btn-social px-2 me-3 text-danger" href="https://www.instagram.com/ramadhani059/"><i class="fab fa-instagram"></i></a>
          <a class="btn btn-light btn-social px-2 me-3 text-danger" href="https://github.com/ramadhani059"><i class="fab fa-github"></i></a>
        </div>
        <p class="m-0">Copyright &copy; 2021 Information System. Build by Pratama Ramadhani Wijaya.</p>
      </div>
    </section>
    <!-- Footer End -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\Users\PRATAMARAMADHANIWIJA\Desktop\website_portfolio_laravel\resources\views/home.blade.php ENDPATH**/ ?>