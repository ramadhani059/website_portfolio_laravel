<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    function home()
    {
        return view('home');
    }

    function portfolio()
    {
        return view('portfolio');
    }

    function music()
    {
        return view('music');
    }

    function contact()
    {
        return view('contact');
    }
}
