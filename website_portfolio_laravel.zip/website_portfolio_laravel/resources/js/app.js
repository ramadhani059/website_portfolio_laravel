require("./bootstrap");
require("./main");
require("./isotope.pkgd.min");

import $ from "jquery";
window.$ = window.jQuery = $;
